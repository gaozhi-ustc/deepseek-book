# deepseek-book Review Bridge Reference

## Active Modules

| File | Role |
| --- | --- |
| `cli.py` | Public entry point: `convert`, `diff`, `export-review`, `import-review`. |
| `md_core.py` | Markdown tokenizer, Block IR, Markdown to DOCX rendering, LaTeX to OMML. |
| `md_formatter.py` | Publishing-format layer: tables, figures, code captions, heading conventions. |
| `md_diff_docx.py` | Markdown block diff to DOCX Track Changes or comment-style output. |
| `docx_reader.py` | Reads DOCX OOXML into Block IR with revisions, comments, tables, equations, figures. |
| `docx_to_md.py` | Matches baseline Markdown blocks to reviewed DOCX blocks, emits `MdEdit`, applies edits, renders commit message. |
| `git_review.py` | Git plumbing, DOCX custom metadata, baseline resolution, reviewer slugging, review branch commits. |
| `comment_classifier.py` | Claude-backed Word comment classification with safe opinion fallback. |

`legacy/` is archival. Do not import or modify it for active work.

## Export Flow

`cli.py export-review RANGE --path path.md`:

1. `git_review.resolve_range()` returns `(base_sha, head_sha)`.
2. `git_review.read_at()` reads both Markdown versions from git.
3. `md_core.parse_md_blocks()` parses both versions.
4. `md_diff_docx.DiffDocxRenderer` writes a DOCX with Track Changes by default.
5. `git_review.stamp_docx_metadata()` writes custom properties:
   `SourceGitCommit`, `SourceBaseCommit`, `SourcePath`, `ReviewExportedAt`.
6. `git_review.update_review_state()` records the export in `.review_state.json`.

Range forms:

- `COMMIT_SHA` means `COMMIT_SHA^..COMMIT_SHA`.
- `BASE_SHA..HEAD_SHA` means explicit base/head.
- `--since-last-review` means `.review_state.json:last_exported_sha..HEAD`.

## Import Flow

`cli.py import-review reviewed.docx --reviewer NAME`:

1. Refuses tracked dirty worktree unless `--allow-dirty`.
2. `git_review.resolve_baseline()` finds `(base_sha, source_path, source_kind)`.
3. Reads baseline Markdown from git with `read_at()`.
4. `docx_reader.read_docx()` reads reviewed DOCX into Block IR.
5. DOCX media are mapped by sha256 for figure replacement.
6. `docx_to_md.make_edits_with_comments()` creates edits, including comment classification.
7. `docx_to_md.apply_edits_to_md()` applies edits in reverse line order.
8. `docx_to_md.render_commit_message()` summarizes edits and warnings.
9. `git_review.commit_to_review_branch()` writes a commit with git plumbing and updates `refs/heads/review/...`.

HEAD and the current branch must remain unchanged.

## Baseline Hints

Resolution order:

1. `docProps/custom.xml`: `SourceGitCommit` and `SourcePath`.
2. Filename suffix: `*_<sha7-or-full>.docx`, requiring `--path`.
3. Sidecar file: `<docx>.base`, requiring `--path`.
4. Explicit CLI flags: `--base SHA --path path.md`.

If metadata contains an existing sha but a missing path, treat it as a sha/path mismatch and ask for corrected `--base --path`.

## Known Limits

- OMML to LaTeX reverse conversion is not implemented; formula edits become placeholders and attachments.
- `md_diff_docx` Track Changes output is for human review, not perfect roundtrip source.
- Plain Word comments require classifier support; no API key means opinion fallback.
- Multi-file batch review, auto-merge, Web UI, and CI are out of scope.
