---
name: md-docx-review-bridge
description: Use when an agent needs to export Markdown git commit diffs to reviewer-facing DOCX files, import reviewed DOCX Track Changes or comments back into Markdown/git diffs, inspect review DOCX metadata, or troubleshoot the deepseek-book md-docx review workflow.
---

# MD DOCX Review Bridge

## Overview

Use the project bridge; do not hand-author OOXML or parse git patches ad hoc. In `deepseek-book`, reviewer exchange flows through `cli.py export-review` and `cli.py import-review`, with review results isolated on `review/<reviewer>-<date>` branches.

## First Checks

1. Work from the repository root containing `cli.py`, `md_core.py`, `docx_reader.py`, `docx_to_md.py`, and `git_review.py`.
2. Use Python 3.10+; on this machine prefer `python3.14`.
3. Ignore `legacy/`; those scripts are archived and not part of the active workflow.
4. If details are unclear, read `references/deepseek-book-review-bridge.md`.
5. For an unknown DOCX, run `python3.14 ~/.codex/skills/md-docx-review-bridge/scripts/inspect_review_docx.py reviewed.docx` before choosing import flags.

## Export Markdown Commit Diff To DOCX

Use this when the user asks for a DOCX for review, annotated DOCX, Word Track Changes, comments from an md commit, or "send this commit/range for review".

```bash
python3.14 cli.py export-review HEAD --path chapter3_new.md
python3.14 cli.py export-review BASE_SHA..HEAD_SHA --path chapter3_new.md
python3.14 cli.py export-review --since-last-review --path chapter3_new.md
python3.14 cli.py export-review HEAD --path chapter3_new.md --comments
```

Default output is `<basename>_<head_sha7>.docx`. Default mode is Track Changes; `--comments` is only for side-comment style review.

After export, verify:

```bash
python3.14 ~/.codex/skills/md-docx-review-bridge/scripts/inspect_review_docx.py chapter3_new_SHA7.docx
python3.14 -c "from git_review import read_docx_metadata; import sys; print(read_docx_metadata(sys.argv[1]))" chapter3_new_SHA7.docx
```

Expected metadata: `SourceGitCommit`, `SourceBaseCommit`, `SourcePath`, `ReviewExportedAt`. `.review_state.json` should update `last_exported_sha`.

## Import Reviewed DOCX To Markdown Diff

Use this when the user gives a reviewed DOCX, asks to read reviewer comments, convert comments/revisions to Markdown changes, generate an md diff, or create a review branch.

```bash
python3.14 cli.py import-review reviewed.docx --reviewer "Reviewer Name"
python3.14 cli.py import-review reviewed.docx --reviewer "Reviewer Name" --base BASE_SHA --path chapter3_new.md
```

`import-review` creates a commit on `review/<reviewer-slug>-<YYYYMMDD>[-N]` and does not switch HEAD. It rejects tracked dirty worktrees unless the user explicitly accepts `--allow-dirty`.

To show the Markdown diff after import:

```bash
git for-each-ref --format='%(refname:short)' refs/heads/review/
git diff BASE_SHA..review/branch-name -- chapter3_new.md
git show --stat --format=fuller review/branch-name
```

Baseline resolution order is metadata, filename `*_<sha7>.docx` plus `--path`, sidecar `<docx>.base` plus `--path`, then explicit `--base --path`.

## Comment Semantics

Comments are classified by `comment_classifier.py`.

- With `ANTHROPIC_API_KEY`, Claude classifies comments as `edit` or `opinion`.
- Only `kind=edit` with `confidence >= 0.7` becomes Markdown text replacement.
- Everything else becomes an HTML comment near the anchor: `<!-- REVIEWER[name]: ... -->`.
- Without an API key, all comments degrade to `opinion`; do not invent replacement text.

## Review Mapping Rules

- Paragraphs and headings become line replacements.
- Lists and code blocks are replaced as whole blocks.
- Same-shape table edits replace changed Markdown table rows; changed table shape replaces the whole table.
- Changed formulas become `<!-- REVIEW: formula changed ... -->` plus `review/attachments/<n>.docx` and optional PNG if LibreOffice exists.
- Changed images are written to `typora-user-images/img-<sha8>.png` and the Markdown image path is updated.
- Conflicting `MdEdit` ranges are applied with later edits winning and warnings added to the commit message.

## Verification

Run focused tests after workflow changes or when diagnosing behavior:

```bash
python3.14 -m pytest tests/test_cli_review.py tests/test_git_review.py tests/test_docx_reader.py tests/test_docx_to_md.py tests/test_comment_classifier.py -v
bash tests/smoke.sh
```

For a quick export/import task, at minimum verify the output DOCX metadata, the `review/` branch, unchanged HEAD, and `git diff BASE_SHA..review/branch-name -- path.md`.

## Common Mistakes

| Mistake | Correction |
| --- | --- |
| Manually editing DOCX XML for normal export/import | Use `cli.py export-review` or `cli.py import-review`. |
| Importing directly into `main` or editing the worktree | Let `commit_to_review_branch()` create a `review/` branch. |
| Asking for `--base` before inspecting metadata | Inspect DOCX metadata first. |
| Treating every Word comment as a text edit | Respect classifier confidence and opinion fallback. |
| Using `legacy/md2docx*.py` | Use active modules only: `md_core.py`, `md_formatter.py`, `md_diff_docx.py`, `docx_reader.py`, `docx_to_md.py`, `git_review.py`. |
