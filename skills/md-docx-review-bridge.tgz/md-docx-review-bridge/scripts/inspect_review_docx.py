#!/usr/bin/env python3
"""Inspect a review DOCX for md-docx bridge metadata and review signals."""

from __future__ import annotations

import json
import os
import re
import sys
import zipfile
from collections import Counter
from xml.etree import ElementTree as ET


W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
CUSTOM_NS = "http://schemas.openxmlformats.org/officeDocument/2006/custom-properties"
VT_NS = "http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"


def _read_metadata(zf: zipfile.ZipFile) -> dict:
    if "docProps/custom.xml" not in zf.namelist():
        return {}
    root = ET.fromstring(zf.read("docProps/custom.xml"))
    result = {}
    for prop in root.findall(f"{{{CUSTOM_NS}}}property"):
        name = prop.attrib.get("name")
        value = prop.find(f"{{{VT_NS}}}lpwstr")
        if name and value is not None and value.text is not None:
            result[name] = value.text
    return result


def _document_counts(zf: zipfile.ZipFile) -> dict:
    if "word/document.xml" not in zf.namelist():
        return {"has_document": False}
    root = ET.fromstring(zf.read("word/document.xml"))
    insert_authors = Counter()
    delete_authors = Counter()
    insert_count = 0
    delete_count = 0
    for el in root.iter():
        if el.tag == f"{{{W_NS}}}ins":
            insert_count += 1
            author = el.attrib.get(f"{{{W_NS}}}author")
            if author:
                insert_authors[author] += 1
        elif el.tag == f"{{{W_NS}}}del":
            delete_count += 1
            author = el.attrib.get(f"{{{W_NS}}}author")
            if author:
                delete_authors[author] += 1
    return {
        "has_document": True,
        "insertions": insert_count,
        "deletions": delete_count,
        "insertion_authors": dict(insert_authors),
        "deletion_authors": dict(delete_authors),
    }


def _comments(zf: zipfile.ZipFile) -> dict:
    if "word/comments.xml" not in zf.namelist():
        return {"count": 0, "authors": {}}
    root = ET.fromstring(zf.read("word/comments.xml"))
    authors = Counter()
    count = 0
    for comment in root.findall(f"{{{W_NS}}}comment"):
        count += 1
        author = comment.attrib.get(f"{{{W_NS}}}author")
        if author:
            authors[author] += 1
    return {"count": count, "authors": dict(authors)}


def inspect(path: str) -> dict:
    with zipfile.ZipFile(path, "r") as zf:
        names = zf.namelist()
        filename_sha = None
        match = re.search(r"_([0-9a-fA-F]{7,40})\.docx$", os.path.basename(path))
        if match:
            filename_sha = match.group(1)
        return {
            "path": path,
            "metadata": _read_metadata(zf),
            "filename_sha_hint": filename_sha,
            "document": _document_counts(zf),
            "comments": _comments(zf),
            "media_count": sum(1 for name in names if name.startswith("word/media/")),
            "has_sidecar_base": os.path.exists(path + ".base"),
        }


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print("usage: inspect_review_docx.py <review.docx>", file=sys.stderr)
        return 2
    path = argv[1]
    try:
        data = inspect(path)
    except (OSError, zipfile.BadZipFile, KeyError, ET.ParseError) as exc:
        print(f"error: cannot inspect {path}: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(data, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
